import sqlite3
from datetime import datetime
from pathlib import Path

tables = [
"""
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    pass_hash TEXT NOT NULL
);
""",
"""
CREATE TABLE diseases (
    name TEXT PRIMARY KEY,
    name_ar TEXT NOT NULL,
    description TEXT NOT NULL,
    description_ar TEXT NOT NULL,
    treatment TEXT NOT NULL,
    treatment_ar TEXT NOT NULL
);
""",
"""
CREATE TABLE analysis (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    file_name TEXT NOT NULL,
    disease TEXT,
    date_taken TEXT NOT NULL,
    time_taken TEXT NOT NULL,

    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(disease) REFERENCES diseases(title)
);
"""
]

diseases = [
    (
        "Septoria",
        "سبتوريا",
        "Septoria disease is a fungal infection in plants, especially wheat and tomatoes, caused by Septoria species. It produces leaf spots, leading to early leaf drop and reduced crop yield. The disease spreads through rain, wind, and tools, thriving in warm, wet conditions.",
        "مرض السبتيوريا هو عدوى فطرية تصيب النباتات، خاصة القمح والطماطم، وتسببه أنواع من فطر السبتيوريا. يسبب بقعًا على الأوراق تؤدي إلى تساقطها مبكرًا وانخفاض في إنتاجية المحصول. ينتشر المرض عن طريق المطر والرياح والأدوات، ويزدهر في الظروف الدافئة والرطبة.",
        "Treatment of Septoria disease includes removing infected leaves, using resistant plant varieties, and applying fungicides like chlorothalonil or copper-based sprays. Ensure good air circulation, avoid overhead watering, and rotate crops to reduce fungal spread.",
        "يشمل علاج مرض السبتيوريا إزالة الأوراق المصابة، واستخدام أصناف نباتية مقاومة، وتطبيق مبيدات الفطريات مثل الكلورثالونيل أو الرشاشات القائمة على النحاس. يجب ضمان تهوية جيدة، وتجنب الري العلوي، وتدوير المحاصيل لتقليل انتشار الفطريات."
    ),
    (
        "Stripe Rust",
        "الصدأ الشريطي",
        "Stripe rust is a fungal disease affecting wheat and other grasses, caused by Puccinia striiformis. It appears as yellow-orange stripes of spores on leaves, reducing photosynthesis and grain yield. The disease spreads by wind and thrives in cool, moist conditions.",
        "الصدأ المخطط هو مرض فطري يصيب القمح وأنواعًا أخرى من الحشائش، وتسببه فطريات بوسينيا سترييفورميس. يظهر على شكل خطوط صفراء إلى برتقالية من الأبواغ على الأوراق، مما يقلل من عملية التمثيل الضوئي وإنتاجية الحبوب. ينتشر المرض عن طريق الرياح ويزدهر في الظروف الباردة والرطبة.",
        "Treatment for stripe rust includes using resistant wheat varieties, applying fungicides like triazoles or strobilurins, and removing infected plants. Early planting and crop rotation help reduce spread. Proper field management, including good air circulation and avoiding excessive nitrogen, can also help manage the disease.",
        "يشمل علاج الصدأ المخطط استخدام أصناف قمح مقاومة، وتطبيق مبيدات فطرية مثل الترايزولات أو الستروبيولورينات، وإزالة النباتات المصابة. يساعد الزراعة المبكرة وتدوير المحاصيل في تقليل الانتشار. كما أن إدارة الحقول بشكل صحيح، بما في ذلك ضمان التهوية الجيدة وتجنب النيتروجين الزائد، يمكن أن يساعد في التحكم في المرض."
    )
]

def database_found():
    file_path = Path("web_database.db")
    if file_path.exists():
        return True
    else:
        return False

def create_database():
    try:
        with sqlite3.connect("web_database.db") as con:
            cur = con.cursor()

            for table in tables:
                cur.execute(table)

            for disease in diseases:
                cur.execute("""
                INSERT INTO diseases (name, name_ar, description, description_ar, treatment, treatment_ar)
                VALUES (?, ?, ?, ?, ?, ?)
                """, disease)

            con.commit()
    except:
        pass

def insert_user(email, first_name, last_name, pass_hash):
    try:
        with sqlite3.connect("web_database.db") as con:
            cur = con.cursor()
            cur.execute("""
            INSERT INTO users (email, first_name, last_name, pass_hash)
            VALUES (?, ?, ?, ?)
            """, (email, first_name, last_name, pass_hash))
            con.commit()
        return True
    except Exception as e:
        print(e)
        return False

def update_user(id, email, first_name, last_name, pass_hash):
    try:
        with sqlite3.connect("web_database.db") as con:
            cur = con.cursor()
            cur.execute("""
            UPDATE users
            SET email = ?, first_name = ?, last_name = ?, pass_hash = ?
            WHERE id = ?
            """, (email, first_name, last_name, pass_hash, id))
            con.commit()
        return True
    except:
        return False

def get_user(email):
    try:
        with sqlite3.connect("web_database.db") as con:
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            record = cur.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            return dict(record)
    except:
        return None
    
def insert_analysis(user_id, file_name, disease):
    date_time_now = datetime.now()
    date_taken = date_time_now.strftime("%d-%m-%Y")
    time_taken = date_time_now.strftime("%H:%M")
    try:
        with sqlite3.connect("web_database.db") as con:
            cur = con.cursor()
            cur.execute("""
            INSERT INTO analysis (user_id, file_name, disease, date_taken, time_taken)
            VALUES (?, ?, ?, ?, ?)
            """, (user_id, file_name, disease, date_taken, time_taken))
            con.commit()
        return True
    except Exception as e:
        print(e)
        return False

def delete_analysis(id):
    try:
        with sqlite3.connect("web_database.db") as con:
            cur = con.cursor()
            cur.execute("DELETE FROM analysis WHERE id = ?", (id,))
            con.commit()
        return True
    except:
        return False
    
def get_user_analysis(user_id):
    try:
        with sqlite3.connect("web_database.db") as con:
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            records = cur.execute("SELECT * FROM analysis WHERE user_id = ? ORDER BY id DESC", (user_id, )).fetchall()
            return [dict(row) for row in records]
    except:
        return None
    
def get_analysis(id):
    try:
        with sqlite3.connect("web_database.db") as con:
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            record = cur.execute("SELECT * FROM analysis WHERE id = ?", (id,)).fetchone()
            return dict(record)
    except:
        return None
    
def get_disease(name):
    try:
        with sqlite3.connect("web_database.db") as con:
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            record = cur.execute("SELECT * FROM diseases WHERE name = ?", (name,)).fetchone()
            return dict(record)
    except:
        return None