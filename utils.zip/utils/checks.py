from re import match, search

def validate_email(email):
    return bool(match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email))

def validate_password(password):
    if len(password) < 8 or not search(r"[a-zA-Z]", password) or not search(r"\d", password):
        return False
    return True

def validate_name(name):
    return bool(match(r"^[a-zA-Z\u0621-\u064A]+$", name))