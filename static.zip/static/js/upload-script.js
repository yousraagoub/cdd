// Elements
const fileInput = document.getElementById("file-input")
const submitButton = document.getElementById("submit-button")


// Functions
function getFileExtension(filename) {
    const lastDotIndex = filename.lastIndexOf(".")
    if (lastDotIndex === -1) return ""
    return filename.substring(lastDotIndex + 1)
}


// Event Handlers
function toggleSubmitButton() {
    const file = fileInput.files[0]

    if (file) {
        const file_size_mb = file.size / 1024 /1024
        const fileExtension = getFileExtension(file.name).toLowerCase()
        if (file_size_mb < 3 && ["png", "jpg", "jpeg"].includes(fileExtension)) {
            submitButton.removeAttribute("disabled")
            fileInput.classList.add("is-valid")
            fileInput.classList.remove("is-invalid")
        }
        else {
            submitButton.setAttribute("disabled", "")
            fileInput.classList.add("is-invalid")
            fileInput.classList.remove("is-valid")
        }
    }
    else {
        submitButton.setAttribute("disabled", "")
        fileInput.classList.remove("is-invalid")
        fileInput.classList.remove("is-valid")
    }
}


// On Load
toggleSubmitButton()


// Event Listeners
fileInput.addEventListener("change", toggleSubmitButton)