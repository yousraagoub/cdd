// Elements
const firstNameInput = document.getElementById("first-name-input")
const lastNameInput = document.getElementById("last-name-input")
const emailInput = document.getElementById("email-input")
const passwordInput = document.getElementById("password-input")
const confirmPasswordInput = document.getElementById("confirm-password-input")

const registerButton = document.getElementById("register-button")
const showPasswordButton = document.getElementsByClassName("bi-eye-slash")[0]


// Functions
function validFirstName() {
    const firstName = firstNameInput.value
    let firstNameValid = /^[a-zA-Z\u0621-\u064A]+$/.test(firstName)

    if (firstName === "") {
        firstNameInput.classList.remove("is-valid")
        firstNameInput.classList.remove("is-invalid")
        firstNameValid = false
    }
    else if (firstNameValid) {
        firstNameInput.classList.remove("is-invalid")
        firstNameInput.classList.add("is-valid")
    }
    else {
        firstNameInput.classList.remove("is-valid")
        firstNameInput.classList.add("is-invalid")
    }

    return firstNameValid
}

function validLastName() {
    const lastName = lastNameInput.value
    let lastNameValid = /^[a-zA-Z\u0621-\u064A]+$/.test(lastName)

    if (lastName === "") {
        lastNameInput.classList.remove("is-valid")
        lastNameInput.classList.remove("is-invalid")
        lastNameValid = false
    }
    else if (lastNameValid) {
        lastNameInput.classList.remove("is-invalid")
        lastNameInput.classList.add("is-valid")
    }
    else {
        lastNameInput.classList.remove("is-valid")
        lastNameInput.classList.add("is-invalid")
    }

    return lastNameValid
}

function validEmail() {
    const email = emailInput.value
    let emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

    if (emailInput.value === "") {
        emailInput.classList.remove("is-valid")
        emailInput.classList.remove("is-invalid")
        emailValid = false
    }
    else if (emailValid) {
        emailInput.classList.remove("is-invalid")
        emailInput.classList.add("is-valid")
    }
    else {
        emailInput.classList.remove("is-valid")
        emailInput.classList.add("is-invalid")
    }

    return emailValid
}

function validPassword() {
    const password = passwordInput.value
    let passwordValid = password.length > 8 && /[A-Za-z]/.test(password) && /[0-9]/.test(password)

    if (passwordInput.value === "") {
        passwordInput.classList.remove("is-valid")
        passwordInput.classList.remove("is-invalid")
        passwordValid = false
    }
    else if (passwordValid) {
        passwordInput.classList.remove("is-invalid")
        passwordInput.classList.add("is-valid")
    }
    else {
        passwordInput.classList.remove("is-valid")
        passwordInput.classList.add("is-invalid")
    }

    return passwordValid
}

function validConfirmPassword() {
    const password = passwordInput.value
    const confirmPassword = confirmPasswordInput.value
    let confirmPasswordValid = password === confirmPassword

    if (password === "" || confirmPassword === "") {
        confirmPasswordInput.classList.remove("is-invalid")
        confirmPasswordInput.classList.remove("is-valid")
        confirmPasswordValid = false
    }
    else if (password === confirmPassword) {
        confirmPasswordInput.classList.remove("is-invalid")
        confirmPasswordInput.classList.add("is-valid")
    }
    else {
        confirmPasswordInput.classList.remove("is-valid")
        confirmPasswordInput.classList.add("is-invalid")
    }

    return confirmPasswordValid
}


// Event Handlers
function toggleShowPassword() {
    if (showPasswordButton.classList.contains("bi-eye-slash")) {
        showPasswordButton.classList.replace("bi-eye-slash", "bi-eye")
        passwordInput.setAttribute("type", "text")
        confirmPasswordInput.setAttribute("type", "text")
    }
    else {
        showPasswordButton.classList.replace("bi-eye", "bi-eye-slash")
        passwordInput.setAttribute("type", "password")
        confirmPasswordInput.setAttribute("type", "password")
    }
}

function toggleRegisterButton() {
    const emailValid = validEmail()
    const passwordValid = validPassword()
    const firstNameValid = validFirstName()
    const lastNameValid = validLastName()
    const confirmPasswordValid = validConfirmPassword()

    if (emailValid && passwordValid && firstNameValid && lastNameValid && confirmPasswordValid) {
        registerButton.removeAttribute("disabled")
    }
    else {
        registerButton.setAttribute("disabled", "")
    }
}


// On Load
toggleRegisterButton()


// Event Listeners
firstNameInput.addEventListener("input", toggleRegisterButton)
lastNameInput.addEventListener("input", toggleRegisterButton)
emailInput.addEventListener("input", toggleRegisterButton)
passwordInput.addEventListener("input", toggleRegisterButton)
confirmPasswordInput.addEventListener("input", toggleRegisterButton)

showPasswordButton.addEventListener("click", toggleShowPassword)